<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>

<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<style type="text/css">
<?php
$desu_logo_url = get_option('x11_logo_url');

if ($desu_logo_url == "") 

{
echo "#logo {background: url(";
echo get_bloginfo('template_url');
echo "/images/logo.png) no-repeat right bottom;}";
}

if ($desu_logo_url == "none") 
{
echo "#logo {background: none;}";
}

if ($desu_logo_url != "" && $desu_logo_url != "none") 
{ 
echo "#logo {background: url(".$desu_logo_url.") no-repeat right bottom;}";
}
?>
</style>

<!--[if IE]>
<style type="text/css">
* html #page {background:url(<?php bloginfo('template_url'); ?>/images/pagebg.gif) repeat top;}
</style>
<script src="<?php bloginfo('template_url'); ?>/js/iefix.js"></script>
<script>
/* <![CDATA[ */
DD_belatedPNG.fix('#logo');
/* ]]> */
</script>
<![endif]-->

<script type="text/javascript">
<!--//--><![CDATA[//><!--
sfHover = function() {
	if (!document.getElementsByTagName) return false;
	var sfEls = document.getElementById("nav").getElementsByTagName("li");


	for (var i=0; i<sfEls.length; i++) {
		sfEls[i].onmouseover=function() {
			this.className+=" sfhover";
		}
		sfEls[i].onmouseout=function() {
			this.className=this.className.replace(new RegExp(" sfhover\\b"), "");
		}
	}

}
if (window.attachEvent) window.attachEvent("onload", sfHover);
//--><!]]>
</script>

<?php wp_get_archives('type=monthly&format=link'); ?>

<?php wp_head(); ?>
</head>
<body>
<?php
$desu_exclude_pages = get_option('x11_exclude_pages');
$desu_exclude_categories = get_option('x11_exclude_categories');
 ?>
<div id="page">


<div id="header">
	<div id="headerimg">
		<h1><a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a></h1>
		<div class="description">&nbsp;<?php bloginfo('description'); ?></div>
		<div id="toprss"><a href="<?php bloginfo('rss2_url'); ?>">RSS News</a> | <a href="<?php bloginfo('comments_rss2_url'); ?>">RSS Comments</a></div>
	</div>
	<div id="logo"></div>
</div>

<div id="navigate">
	<ul><li<?php if ( is_home() ) { ?> class="current_page_item"<?php } ?> id="firstlink"><a href="<?php bloginfo('siteurl');?>">Home</a></li>
	<?php wp_list_pages('sort_column=menu_order&depth=1&exclude='.$desu_exclude_pages.'&title_li='); ?>
	</ul>
	<div id="topsearch">
<form method="get" id="searchform" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<input type="text" value="<?php echo wp_specialchars($s, 1); ?>" name="s" id="s" />
<input type="submit" id="searchsubmit" value="Search" />
</form>
</div>
</div>

<div id="subnav2">
	<ul id="nav"><?php wp_list_categories('exclude='.$desu_exclude_categories.'&title_li=&depth=2'); ?></ul>
</div>
	
<div id="opener">