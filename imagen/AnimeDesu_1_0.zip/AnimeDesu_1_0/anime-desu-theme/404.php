<?php get_header(); ?>
<div id="wrapper">
	<div id="content">

		<h2 class="center">Error 404 - Not Found</h2>

	</div>

<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>