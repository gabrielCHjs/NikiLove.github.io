</div>

<div id="footer">
		<div id="copyright">Copyright &copy;<?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All Rights Reserved. Theme by <a href="http://templates.animemeeting.com/">Animemeeting</a></div>
		<div id="designed"><a href="http://www.animemeeting.com/"> </a></div>
</div>
</div>

		<?php wp_footer(); ?>

</body>
</html>