<?php get_header(); ?>
<div id="wrapper"><?php 
	$desu_adsense_code = get_option('x11_adsense_code');
if ($desu_adsense_code =="" || $desu_adsense_code ==" ") :
?>
<?php else: ?>
	<div id="adsense"><?php echo stripslashes($desu_adsense_code); ?></div>
<?php endif ?>	
	<div id="content">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
		<h2><?php the_title(); ?></h2>
			<div class="entrytext">
				<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
	
				<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
	
			</div>
		</div>
	  <?php endwhile; endif; ?>
	<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
	</div>

<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>